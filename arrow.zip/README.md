# arrow-text-editor

To install:

1) Extract "arrow-text-editor" to Downloads
2) Open the terminal
3) Type: chmod +x ~/Downloads/arrow/Install_Arrow && .~/Downloads/arrow/Install_Arrow

To use:

Open the terminal and type: arrow

To uninstall:

Open the terminal and type: arrow-uninstall && sudo rm /usr/bin/arrow-uninstall





Enjoy using the text editor!
